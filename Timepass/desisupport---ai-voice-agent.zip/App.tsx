import React from 'react';
import { useLiveGemini } from './hooks/useLiveGemini';
import { ConnectionState } from './types';
import { AudioVisualizer } from './components/AudioVisualizer';
import { Transcript } from './components/Transcript';

export default function App() {
  const { 
    connect, 
    disconnect, 
    connectionState, 
    isSpeaking, 
    analyser, 
    messages 
  } = useLiveGemini();

  const handleToggleConnection = () => {
    if (connectionState === ConnectionState.CONNECTED || connectionState === ConnectionState.CONNECTING) {
      disconnect();
    } else {
      connect();
    }
  };

  return (
    <div className="flex flex-col h-screen bg-slate-50 font-sans">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between shadow-sm z-10">
        <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-500 to-amber-600 flex items-center justify-center text-white shadow-md">
                <i className="fas fa-headset text-lg"></i>
            </div>
            <div>
                <h1 className="text-xl font-bold text-slate-800 tracking-tight">DesiSupport</h1>
                <p className="text-xs text-slate-500 font-medium">Customer Service • Live Agent</p>
            </div>
        </div>
        
        <div className="flex items-center gap-4">
             {/* Status Pill */}
             <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold border ${
                connectionState === ConnectionState.CONNECTED 
                    ? 'bg-green-50 text-green-700 border-green-200'
                    : connectionState === ConnectionState.CONNECTING
                    ? 'bg-yellow-50 text-yellow-700 border-yellow-200'
                    : 'bg-slate-100 text-slate-600 border-slate-200'
             }`}>
                <div className={`w-2 h-2 rounded-full ${
                    connectionState === ConnectionState.CONNECTED ? 'bg-green-500 animate-pulse' : 
                    connectionState === ConnectionState.CONNECTING ? 'bg-yellow-500 animate-bounce' : 'bg-slate-400'
                }`}></div>
                {connectionState === ConnectionState.CONNECTED ? 'LIVE' : 
                 connectionState === ConnectionState.CONNECTING ? 'CONNECTING...' : 'OFFLINE'}
             </div>
        </div>
      </header>

      {/* Main Content Grid */}
      <main className="flex-1 flex overflow-hidden max-w-7xl mx-auto w-full p-4 gap-4">
        
        {/* Left Panel: Visualizer & Controls */}
        <section className="flex-1 flex flex-col gap-4 min-w-[300px]">
            {/* Visualizer Card */}
            <div className="flex-1 bg-white rounded-3xl shadow-sm border border-slate-200 relative overflow-hidden flex flex-col items-center justify-center p-8">
                {/* Background Decor */}
                <div className="absolute inset-0 opacity-5 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
                
                {/* Agent Avatar Area */}
                <div className="relative z-10 flex flex-col items-center gap-6 w-full h-full justify-center">
                    <div className="relative w-64 h-64">
                         {/* Visualizer Canvas Layer */}
                        <div className="absolute inset-0 flex items-center justify-center">
                             <AudioVisualizer 
                                analyser={analyser} 
                                isConnected={connectionState === ConnectionState.CONNECTED}
                                isSpeaking={isSpeaking}
                            />
                        </div>
                    </div>

                    <div className="text-center space-y-2">
                        <h2 className="text-2xl font-semibold text-slate-800">
                            {connectionState === ConnectionState.CONNECTED 
                                ? (isSpeaking ? "Arya is speaking..." : "Arya is listening...") 
                                : "Ready to help"}
                        </h2>
                        <p className="text-slate-500 text-sm max-w-xs mx-auto">
                            {connectionState === ConnectionState.CONNECTED 
                             ? "Speak naturally. I can help with your orders and queries."
                             : "Click the microphone button below to start a conversation with our support agent."}
                        </p>
                    </div>
                </div>
            </div>

            {/* Control Bar */}
            <div className="h-24 bg-white rounded-3xl shadow-sm border border-slate-200 flex items-center justify-center gap-6 px-8">
                <button 
                    onClick={handleToggleConnection}
                    className={`
                        w-16 h-16 rounded-full flex items-center justify-center text-2xl shadow-lg transition-all duration-300 transform hover:scale-105 active:scale-95
                        ${connectionState === ConnectionState.CONNECTED 
                            ? 'bg-red-500 hover:bg-red-600 text-white shadow-red-200' 
                            : 'bg-slate-900 hover:bg-slate-800 text-white shadow-slate-200'
                        }
                    `}
                    title={connectionState === ConnectionState.CONNECTED ? "Disconnect" : "Connect"}
                >
                    <i className={`fas ${connectionState === ConnectionState.CONNECTED ? 'fa-phone-slash' : 'fa-microphone'}`}></i>
                </button>
                
                {connectionState === ConnectionState.CONNECTED && (
                    <div className="absolute right-10 flex gap-2">
                        {/* Placeholder for Mute Button if needed later */}
                        {/* <button className="w-12 h-12 rounded-full bg-slate-100 text-slate-600 hover:bg-slate-200 flex items-center justify-center">
                            <i className="fas fa-microphone-slash"></i>
                        </button> */}
                    </div>
                )}
            </div>
        </section>

        {/* Right Panel: Transcript */}
        <section className="w-full max-w-md hidden lg:flex flex-col bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="p-4 border-b border-slate-100 bg-slate-50/50">
                <h3 className="font-semibold text-slate-700 flex items-center gap-2">
                    <i className="fas fa-align-left text-slate-400"></i>
                    Live Transcript
                </h3>
            </div>
            <div className="flex-1 relative">
                <div className="absolute inset-0">
                    <Transcript messages={messages} />
                </div>
            </div>
        </section>

      </main>
      
      {/* Mobile Transcript Overlay (could be added for mobile view) */}
    </div>
  );
}