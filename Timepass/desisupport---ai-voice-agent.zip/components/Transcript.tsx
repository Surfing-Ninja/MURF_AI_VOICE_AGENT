import React, { useEffect, useRef } from 'react';
import { Message } from '../types';

interface TranscriptProps {
  messages: Message[];
}

export const Transcript: React.FC<TranscriptProps> = ({ messages }) => {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  if (messages.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-slate-400 text-sm">
        <i className="fas fa-comment-slash mb-2 text-2xl"></i>
        <p>No conversation yet. Connect to start.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col space-y-4 p-4 overflow-y-auto h-full scrollbar-hide">
      {messages.map((msg) => (
        <div
          key={msg.id}
          className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
        >
          <div
            className={`max-w-[80%] rounded-2xl px-4 py-3 shadow-sm ${
              msg.role === 'user'
                ? 'bg-orange-100 text-orange-900 rounded-br-none'
                : 'bg-white text-slate-800 border border-slate-100 rounded-bl-none'
            }`}
          >
            <div className="flex items-center gap-2 mb-1">
                <span className={`text-xs font-bold uppercase ${msg.role === 'user' ? 'text-orange-600' : 'text-slate-500'}`}>
                    {msg.role === 'user' ? 'You' : 'Arya (DesiMart)'}
                </span>
                <span className="text-[10px] text-slate-400">
                    {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
            </div>
            <p className="text-sm leading-relaxed">{msg.text}</p>
          </div>
        </div>
      ))}
      <div ref={bottomRef} />
    </div>
  );
};