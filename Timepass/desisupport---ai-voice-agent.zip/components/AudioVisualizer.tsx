import React, { useEffect, useRef } from 'react';
import { AudioVisualizerProps } from '../types';

export const AudioVisualizer: React.FC<AudioVisualizerProps> = ({ analyser, isConnected, isSpeaking }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    const resizeCanvas = () => {
      canvas.width = canvas.parentElement?.clientWidth || 300;
      canvas.height = canvas.parentElement?.clientHeight || 150;
    };
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    const draw = () => {
      if (!analyser || !isConnected) {
        // Idle animation
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Draw a gentle breathing circle if connected but not speaking
        if (isConnected) {
            const time = Date.now() / 1000;
            const radius = 30 + Math.sin(time * 2) * 2;
            ctx.beginPath();
            ctx.arc(canvas.width / 2, canvas.height / 2, radius, 0, 2 * Math.PI);
            ctx.fillStyle = isSpeaking ? '#f97316' : '#94a3b8'; // Orange if speaking, slate if listening
            ctx.fill();
            
            // Pulse ring
            ctx.beginPath();
            ctx.arc(canvas.width / 2, canvas.height / 2, radius + 10, 0, 2 * Math.PI);
            ctx.strokeStyle = isSpeaking ? 'rgba(249, 115, 22, 0.3)' : 'rgba(148, 163, 184, 0.3)';
            ctx.lineWidth = 2;
            ctx.stroke();
        } else {
             // Disconnected state
             ctx.fillStyle = '#e2e8f0';
             ctx.beginPath();
             ctx.arc(canvas.width / 2, canvas.height / 2, 20, 0, 2 * Math.PI);
             ctx.fill();
        }
        
        animationRef.current = requestAnimationFrame(draw);
        return;
      }

      // Active visualization
      const bufferLength = analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);
      analyser.getByteFrequencyData(dataArray);

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;
      const radius = 50;
      
      ctx.beginPath();
      // Create a circular waveform
      for (let i = 0; i < bufferLength; i++) {
        const rads = (Math.PI * 2) / bufferLength;
        const barHeight = (dataArray[i] / 255) * 60; // Scale height
        const x = centerX + Math.cos(rads * i) * (radius + barHeight);
        const y = centerY + Math.sin(rads * i) * (radius + barHeight);
        
        if (i === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
      }
      ctx.closePath();
      
      // Dynamic gradient
      const gradient = ctx.createRadialGradient(centerX, centerY, radius - 10, centerX, centerY, radius + 60);
      gradient.addColorStop(0, '#f97316'); // Orange-500
      gradient.addColorStop(1, '#ea580c'); // Orange-600

      ctx.fillStyle = gradient;
      ctx.fill();

      // Inner glow
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius - 5, 0, 2 * Math.PI);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
      ctx.fill();

      animationRef.current = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
      window.removeEventListener('resize', resizeCanvas);
    };
  }, [analyser, isConnected, isSpeaking]);

  return <canvas ref={canvasRef} className="w-full h-full" />;
};