import { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { ConnectionState, Message } from '../types';
import { createPcmBlob, decodeAudioData, base64ToUint8Array, audioBufferToResampledPcmBlob } from '../utils/audioUtils';

// Audio config constants
// Note: We do not force INPUT_SAMPLE_RATE on the context anymore to avoid browser issues, 
// but we still resample to 16000 for the API.
const TARGET_API_SAMPLE_RATE = 16000; 
const OUTPUT_SAMPLE_RATE = 24000;
const BUFFER_SIZE = 4096;

const SYSTEM_INSTRUCTION = `You are 'Arya', a friendly, professional, and culturally attuned customer support representative for 'DesiMart', a leading Indian e-commerce platform. 
Your goal is to assist customers with orders, refunds, and product questions.
Key Traits:
1. **Language**: Speak fluent English but naturally mix in common Indian-English phrases (Hinglish) and polite honorifics. E.g., use "Namaste", "Ji" (e.g., "Rahul-ji"), "Please do the needful", "I will revert back to you", "Don't worry at all".
2. **Tone**: Warm, patient, empathetic, and respectful. Indian service culture values politeness highly.
3. **Context**: Currency is Indian Rupees (₹). Popular festivals are Diwali, Holi, Eid.
4. **Behavior**: Listen carefully. If you don't understand, ask politely "Pardon me?". Keep responses concise (under 2-3 sentences) unless explaining a process.
5. **Scenario**: The user is a customer calling the helpline. Start by greeting them warmly with "Namaste! Welcome to DesiMart support. I am Arya. How can I help you today?"`;

export const useLiveGemini = () => {
  const [connectionState, setConnectionState] = useState<ConnectionState>(ConnectionState.DISCONNECTED);
  const [isSpeaking, setIsSpeaking] = useState(false); // Model is speaking
  const [messages, setMessages] = useState<Message[]>([]);
  
  // Refs for audio context and cleanup
  const inputContextRef = useRef<AudioContext | null>(null);
  const outputContextRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const sourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  
  // Queue management for smooth playback
  const nextStartTimeRef = useRef<number>(0);
  const scheduledSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  
  // Transcription buffers
  const currentInputTransRef = useRef('');
  const currentOutputTransRef = useRef('');

  // Helper to disconnect and cleanup
  const disconnect = useCallback(() => {
    // 1. Close Microphone Stream
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }

    // 2. Disconnect Input Processing
    if (processorRef.current) {
      processorRef.current.disconnect();
      processorRef.current.onaudioprocess = null; // Prevent memory leaks
      processorRef.current = null;
    }
    if (sourceRef.current) {
      sourceRef.current.disconnect();
      sourceRef.current = null;
    }
    if (inputContextRef.current) {
      inputContextRef.current.close();
      inputContextRef.current = null;
    }

    // 3. Stop Output Playback
    scheduledSourcesRef.current.forEach(source => {
      try {
        source.stop();
      } catch (e) { /* ignore already stopped */ }
    });
    scheduledSourcesRef.current.clear();
    
    if (outputContextRef.current) {
      outputContextRef.current.close();
      outputContextRef.current = null;
    }

    setConnectionState(ConnectionState.DISCONNECTED);
    setIsSpeaking(false);
    nextStartTimeRef.current = 0;
  }, []);

  const connect = useCallback(async () => {
    if (!process.env.API_KEY) {
      alert("API Key is missing in environment variables.");
      return;
    }

    try {
      setConnectionState(ConnectionState.CONNECTING);
      
      // Initialize Audio Contexts
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      
      // Input context: Allow default sample rate to match hardware/browser preference
      // This prevents issues where getUserMedia stream sample rate doesn't match context
      const inputCtx = new AudioContextClass(); 
      
      // Output context: Gemini returns 24000Hz audio
      const outputCtx = new AudioContextClass({ sampleRate: OUTPUT_SAMPLE_RATE });
      
      // Ensure contexts are running (vital for some browsers)
      if (inputCtx.state === 'suspended') {
        await inputCtx.resume();
      }
      if (outputCtx.state === 'suspended') {
        await outputCtx.resume();
      }

      // Analyzer for visualization - Connect to destination ONCE
      const analyser = outputCtx.createAnalyser();
      analyser.fftSize = 256;
      analyser.connect(outputCtx.destination);
      analyserRef.current = analyser;

      inputContextRef.current = inputCtx;
      outputContextRef.current = outputCtx;

      // Get Microphone Access
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      // Setup Gemini Client
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      // Connect to Live API
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
          },
          systemInstruction: SYSTEM_INSTRUCTION,
          inputAudioTranscription: {}, 
          outputAudioTranscription: {},
        },
        callbacks: {
          onopen: () => {
            setConnectionState(ConnectionState.CONNECTED);
            
            // Start processing microphone input
            const source = inputCtx.createMediaStreamSource(stream);
            const processor = inputCtx.createScriptProcessor(BUFFER_SIZE, 1, 1);
            
            processor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              
              // CRITICAL: Resample to 16000Hz before sending
              // Most microphones are 44.1k or 48k. Gemini Live API requires 16k PCM.
              const blob = audioBufferToResampledPcmBlob(
                  inputData, 
                  inputCtx.sampleRate, 
                  TARGET_API_SAMPLE_RATE
              );
              
              // Send to Gemini
              sessionPromise.then(session => {
                session.sendRealtimeInput({ media: blob });
              });
            };

            source.connect(processor);
            processor.connect(inputCtx.destination);
            
            sourceRef.current = source;
            processorRef.current = processor;
          },
          onmessage: async (msg: LiveServerMessage) => {
            const { serverContent } = msg;

            // 1. Handle Audio Output
            const audioData = serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (audioData && outputContextRef.current) {
                const ctx = outputContextRef.current;
                
                // Decode
                const audioBuffer = await decodeAudioData(
                    base64ToUint8Array(audioData),
                    ctx,
                    OUTPUT_SAMPLE_RATE,
                    1
                );

                // Scheduling
                // Ensure we don't schedule in the past
                const currentTime = ctx.currentTime;
                if (nextStartTimeRef.current < currentTime) {
                    nextStartTimeRef.current = currentTime;
                }

                const source = ctx.createBufferSource();
                source.buffer = audioBuffer;
                
                // Connect to analyser (which is already connected to destination)
                source.connect(analyser);
                // Note: No need to connect to destination here as analyser is already connected

                source.start(nextStartTimeRef.current);
                
                // Track source for cancellation
                scheduledSourcesRef.current.add(source);
                
                source.onended = () => {
                   scheduledSourcesRef.current.delete(source);
                   if (scheduledSourcesRef.current.size === 0) {
                       setIsSpeaking(false);
                   }
                };
                
                setIsSpeaking(true);
                nextStartTimeRef.current += audioBuffer.duration;
            }

            // 2. Handle Interruption
            if (serverContent?.interrupted) {
                 scheduledSourcesRef.current.forEach(s => s.stop());
                 scheduledSourcesRef.current.clear();
                 nextStartTimeRef.current = 0;
                 setIsSpeaking(false);
                 // Clear pending transcription buffers on interrupt
                 currentInputTransRef.current = '';
                 currentOutputTransRef.current = '';
            }

            // 3. Handle Transcription
            // Accumulate chunks
            if (serverContent?.inputTranscription?.text) {
                currentInputTransRef.current += serverContent.inputTranscription.text;
            }
            if (serverContent?.outputTranscription?.text) {
                currentOutputTransRef.current += serverContent.outputTranscription.text;
            }

            // Turn complete: commit messages
            if (serverContent?.turnComplete) {
                if (currentInputTransRef.current.trim()) {
                    setMessages(prev => [...prev, {
                        id: Date.now().toString() + '-user',
                        role: 'user',
                        text: currentInputTransRef.current,
                        timestamp: new Date()
                    }]);
                    currentInputTransRef.current = '';
                }
                
                if (currentOutputTransRef.current.trim()) {
                     setMessages(prev => [...prev, {
                        id: Date.now().toString() + '-agent',
                        role: 'agent',
                        text: currentOutputTransRef.current,
                        timestamp: new Date()
                    }]);
                    currentOutputTransRef.current = '';
                }
            }
          },
          onclose: () => {
            console.log("Session closed");
            disconnect();
          },
          onerror: (err) => {
            console.error("Session error:", err);
            disconnect();
            setConnectionState(ConnectionState.ERROR);
          }
        }
      });
    } catch (error) {
      console.error("Failed to connect:", error);
      disconnect();
      setConnectionState(ConnectionState.ERROR);
    }
  }, [disconnect]);

  return {
    connect,
    disconnect,
    connectionState,
    isSpeaking,
    analyser: analyserRef.current,
    messages
  };
};